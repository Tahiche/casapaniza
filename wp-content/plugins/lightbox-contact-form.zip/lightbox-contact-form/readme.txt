=== Constant Contact WordPress Widget ===
Contributors: www.alphachannelgroup.com
Tags: email list, newsletter signup, mailing list manager, email list manager, newsletter list manager
Tested up to: 2.8.7
Stable tag: 1.0

This widget adds a newsletter sign-up form to your WordPress blog, as well as the ability to import, export, and manage the list from within the dashboard.

== Description ==
Easily capture e-mails through a double opt-in form.
Easily add, edit, and delete e-mails through the manager page, or the import/export functions.
Easily copy-and-paste the list of e-mails into your favorite e-mail program to send to all of the e-mails in your list.
